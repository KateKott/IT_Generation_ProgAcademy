package org.prog.web;

public class SomeClass {

  public void smth(){
    SeleniumDemo seleniumDemo = new SeleniumDemo();
    seleniumDemo.someMethod();
  }
}
