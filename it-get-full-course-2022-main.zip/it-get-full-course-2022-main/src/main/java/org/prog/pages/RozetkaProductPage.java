package org.prog.pages;

import org.openqa.selenium.WebDriver;

public class RozetkaProductPage {


}
