create table Persons (PersonID int(11) PRIMARY KEY AUTO_INCREMENT NOT NULL ,
                      LastName varchar(200), FirstName varchar(200), Title varchar(4), Gender varchar(15));